<?php
// To
define("WEBMASTER_EMAIL", 'ezek19@mail.com');
?>